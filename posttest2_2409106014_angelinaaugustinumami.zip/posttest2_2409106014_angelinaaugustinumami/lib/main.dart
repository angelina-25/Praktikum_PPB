import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'pages/order_page.dart';
import 'pages/profile_page.dart';
import 'pages/new_order_page.dart';

void main() {
  runApp(const LaundryKuApp());
}

// Widget utama aplikasi LaundryKu
class LaundryKuApp extends StatelessWidget {
  const LaundryKuApp({super.key});

  @override
  Widget build(BuildContext context) {
    // MaterialApp digunakan sebagai wrapper utama aplikasi Flutter
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'LaundryKu',

      // ThemeData digunakan untuk mengatur tema aplikasi
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4A90E2),
        ),
        useMaterial3: true,
      ),

      // Halaman pertama yang ditampilkan adalah HomePage
      home: const HomePage(),
    );
  }
}

// Halaman utama LaundryKu
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Menyimpan index halaman yang sedang aktif pada NavigationBar
  int currentIndex = 0;

  // Daftar halaman untuk NavigationBar
  final List<Widget> pages = const [
    HomeContent(),
    OrderPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur utama halaman
    return Scaffold(
      // Menampilkan halaman sesuai index NavigationBar
      body: pages[currentIndex],

      // NavigationBar digunakan untuk berpindah antar halaman utama
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex,

        // Callback ketika item NavigationBar ditekan
        onDestinationSelected: (index) {
          setState(() {
            currentIndex = index;
          });
        },

        // NavigationDestination digunakan untuk membuat item menu
        destinations: const [
          NavigationDestination(
            // Icon digunakan untuk icon Home
            icon: Icon(Icons.home_outlined),
            // Icon yang tampil ketika dipilih
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),

          NavigationDestination(
            // Icon digunakan untuk menu Pesanan
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Pesanan',
          ),

          NavigationDestination(
            // Icon digunakan untuk menu Profil
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}

// Isi halaman Home
class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur halaman Home
    return Scaffold(
      backgroundColor: const Color(0xFFF5F9FF),

      // AppBar digunakan sebagai bagian atas halaman
      appBar: AppBar(
        backgroundColor: const Color(0xFF4A90E2),
        foregroundColor: Colors.white,

        // Row digunakan untuk menyusun logo dan nama aplikasi secara horizontal
        title: Row(
          children: [
            // Image.asset digunakan untuk menampilkan gambar laundry
            Image.asset(
              'assets/laundry.png',
              width: 35,
              height: 35,
              fit: BoxFit.cover,
            ),

            const SizedBox(width: 10),

            // Text digunakan untuk menampilkan nama aplikasi
            const Text(
              'LaundryKu',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),

      // SingleChildScrollView digunakan agar halaman dapat di-scroll
      body: SingleChildScrollView(
        // Padding digunakan untuk memberikan jarak isi halaman
        padding: const EdgeInsets.all(20),

        // Column digunakan untuk menyusun widget secara vertikal
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Text digunakan untuk ucapan selamat datang
            const Text(
              'Halo, Selamat Datang! 👋',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            // Text digunakan untuk deskripsi aplikasi
            const Text(
              'Kelola kebutuhan laundry kamu dengan mudah.',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 16,
              ),
            ),

            const SizedBox(height: 25),

            // TextField digunakan sebagai kolom pencarian
            TextField(
              decoration: InputDecoration(
                hintText: 'Cari pesanan atau pelanggan...',

                // Icon digunakan sebagai icon pencarian
                prefixIcon: const Icon(Icons.search),

                // OutlineInputBorder digunakan untuk membuat border TextField
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide.none,
                ),

                // Filled digunakan untuk memberikan warna pada TextField
                filled: true,
                fillColor: Colors.white,
              ),
            ),

            const SizedBox(height: 25),

            // Text sebagai judul ringkasan
            const Text(
              'Ringkasan Laundry',
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 15),

            // Row digunakan untuk membuat dua kartu berdampingan
            Row(
              children: [
                // Expanded digunakan agar kartu membagi ruang secara proporsional
                Expanded(
                  child: _summaryCard(
                    icon: Icons.shopping_bag_outlined,
                    number: '12',
                    label: 'Pesanan Masuk',
                    color: const Color(0xFFE4F0FF),
                  ),
                ),

                const SizedBox(width: 12),

                // Expanded digunakan untuk kartu kedua
                Expanded(
                  child: _summaryCard(
                    icon: Icons.check_circle_outline,
                    number: '8',
                    label: 'Sudah Selesai',
                    color: const Color(0xFFE5F8EC),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 25),

            // Text digunakan sebagai judul layanan
            const Text(
              'Layanan Laundry',
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 15),

            // Stack digunakan untuk menumpuk beberapa widget pada area yang sama
            Stack(
              children: [
                // Container digunakan sebagai kartu layanan
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),

                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),

                    // BoxShadow digunakan untuk memberikan efek bayangan
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.shade300,
                        blurRadius: 10,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),

                  child: Row(
                    children: [
                      // Container digunakan sebagai background icon
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE4F0FF),
                          borderRadius: BorderRadius.circular(15),
                        ),

                        // Icon digunakan sebagai icon mesin cuci
                        child: const Icon(
                          Icons.local_laundry_service,
                          color: Color(0xFF4A90E2),
                          size: 30,
                        ),
                      ),

                      const SizedBox(width: 15),

                      // Expanded digunakan agar informasi layanan mengambil ruang tersedia
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Text menampilkan nama layanan
                            Text(
                              'Cuci Kiloan',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            SizedBox(height: 5),

                            // Text menampilkan harga layanan
                            Text(
                              'Mulai dari Rp7.000 / kg',
                              style: TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Icon menunjukkan tombol detail
                      const Icon(
                        Icons.chevron_right,
                        color: Colors.grey,
                      ),
                    ],
                  ),
                ),

                // Positioned digunakan untuk menempatkan badge di dalam Stack
                const Positioned(
                  top: 10,
                  right: 10,

                  // Container digunakan sebagai badge layanan
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: Color(0xFF4A90E2),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),

                    // Padding digunakan untuk memberikan jarak pada badge
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),

                      // Text digunakan untuk tulisan badge
                      child: Text(
                        'Populer',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // Container digunakan sebagai tombol buat pesanan
            GestureDetector(
              // GestureDetector digunakan untuk menangani klik pengguna
              onTap: () {
                // Navigator.push digunakan untuk membuka halaman baru
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    // MaterialPageRoute digunakan untuk berpindah ke halaman pesanan
                    builder: (context) => const NewOrderPage(),
                  ),
                );
              },

              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),

                decoration: BoxDecoration(
                  color: const Color(0xFF4A90E2),
                  borderRadius: BorderRadius.circular(18),

                  // BoxShadow digunakan untuk efek bayangan tombol
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade300,
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),

                child: const Row(
                  children: [
                    // Icon digunakan untuk tombol tambah pesanan
                    Icon(
                      Icons.add_circle_outline,
                      color: Colors.white,
                      size: 32,
                    ),

                    SizedBox(width: 15),

                    // Expanded digunakan agar teks mengambil ruang yang tersedia
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Text sebagai judul tombol
                          Text(
                            'Buat Pesanan Baru',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          // Text sebagai keterangan tombol
                          Text(
                            'Catat pesanan laundry pelanggan',
                            style: TextStyle(
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Icon digunakan sebagai tanda navigasi
                    Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Fungsi untuk membuat kartu ringkasan
  Widget _summaryCard({
    required IconData icon,
    required String number,
    required String label,
    required Color color,
  }) {
    // Container digunakan sebagai kartu ringkasan
    return Container(
      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(18),
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Icon digunakan untuk icon ringkasan
          Icon(
            icon,
            size: 30,
            color: const Color(0xFF4A90E2),
          ),

          const SizedBox(height: 15),

          // Text digunakan untuk angka jumlah pesanan
          Text(
            number,
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),

          // Text digunakan untuk label jumlah pesanan
          Text(
            label,
            style: const TextStyle(
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }
}