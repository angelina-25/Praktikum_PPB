import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NewOrderPage extends StatefulWidget {
  const NewOrderPage({super.key});

  @override
  State<NewOrderPage> createState() => _NewOrderPageState();
}

class _NewOrderPageState extends State<NewOrderPage> {
  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur utama halaman
    return Scaffold(
      // AppBar digunakan sebagai header halaman
      appBar: AppBar(
        title: const Text('Pesanan Baru'),
        backgroundColor: const Color(0xFF4A90E2),
        foregroundColor: Colors.white,

        // Tombol kembali menggunakan Navigator.pop
        leading: IconButton(
          // IconButton digunakan sebagai tombol kembali
          icon: const Icon(Icons.arrow_back),

          onPressed: () {
            // Navigator.pop digunakan untuk kembali ke halaman sebelumnya
            Navigator.pop(context);
          },
        ),
      ),

      // SingleChildScrollView digunakan agar form dapat di-scroll
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),

        // Column digunakan untuk menyusun form secara vertikal
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Text digunakan sebagai judul form
            const Text(
              'Buat Pesanan Laundry',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 25),

            // Text digunakan sebagai label input nama
            const Text(
              'Nama Pelanggan',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            // TextField digunakan untuk memasukkan nama pelanggan
            TextField(
              decoration: InputDecoration(
                hintText: 'Masukkan nama pelanggan',

                // Icon digunakan sebagai icon nama pelanggan
                prefixIcon: const Icon(Icons.person),

                // OutlineInputBorder digunakan untuk border input
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Text sebagai label berat laundry
            const Text(
              'Berat Laundry (kg)',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            // TextField digunakan untuk memasukkan berat laundry
            TextField(
              keyboardType: TextInputType.number,

              // FilteringTextInputFormatter digunakan agar hanya angka yang diterima
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
              ],

              decoration: InputDecoration(
                hintText: 'Contoh: 3',

                // Icon digunakan untuk icon berat laundry
                prefixIcon: const Icon(Icons.scale),

                // OutlineInputBorder digunakan untuk border TextField
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),

            const SizedBox(height: 25),

            // SizedBox digunakan untuk mengatur ukuran tombol
            SizedBox(
              width: double.infinity,

              // ElevatedButton digunakan sebagai tombol simpan
              child: ElevatedButton.icon(
                // Icon digunakan pada tombol simpan
                icon: const Icon(Icons.save),

                // Label tombol
                label: const Text('Simpan Pesanan'),

                onPressed: () {
                  // Navigator.pop digunakan untuk kembali setelah pesanan disimpan
                  Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}