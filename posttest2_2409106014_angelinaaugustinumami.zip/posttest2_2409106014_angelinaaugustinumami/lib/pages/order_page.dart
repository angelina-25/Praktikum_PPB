import 'package:flutter/material.dart';

class OrderPage extends StatelessWidget {
  const OrderPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur utama halaman Pesanan
    return Scaffold(
      // AppBar digunakan sebagai bagian atas halaman
      appBar: AppBar(
        title: const Text('Pesanan Laundry'),
        backgroundColor: const Color(0xFF4A90E2),
        foregroundColor: Colors.white,
      ),

      // ListView digunakan untuk menampilkan daftar pesanan
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Card digunakan sebagai wadah informasi pesanan
          Card(
            // Padding digunakan untuk memberikan jarak isi Card
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // CircleAvatar digunakan untuk icon/status pesanan
                  const CircleAvatar(
                    backgroundColor: Color(0xFFE4F0FF),
                    child: Icon(
                      Icons.local_laundry_service,
                      color: Color(0xFF4A90E2),
                    ),
                  ),

                  const SizedBox(width: 15),

                  // Expanded digunakan agar informasi pesanan mengambil ruang
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Text menampilkan nama pelanggan
                        Text(
                          'Angelina',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 17,
                          ),
                        ),

                        // Text menampilkan detail pesanan
                        Text(
                          'Cuci Kiloan • 3 kg',
                          style: TextStyle(
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Chip digunakan untuk menampilkan status
                  const Chip(
                    label: Text('Selesai'),
                  ),
                ],
              ),
            ),
          ),

          // Card kedua untuk pesanan
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // CircleAvatar digunakan sebagai icon pesanan
                  const CircleAvatar(
                    backgroundColor: Color(0xFFFFF0D9),
                    child: Icon(
                      Icons.shopping_bag,
                      color: Colors.orange,
                    ),
                  ),

                  const SizedBox(width: 15),

                  // Expanded digunakan untuk informasi pesanan
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Text nama pelanggan
                        Text(
                          'Putri',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 17,
                          ),
                        ),

                        // Text detail pesanan
                        Text(
                          'Cuci Satuan • 5 pcs',
                          style: TextStyle(
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Chip digunakan untuk status proses
                  const Chip(
                    label: Text('Proses'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}