import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur utama halaman Profil
    return Scaffold(
      // AppBar digunakan sebagai header halaman
      appBar: AppBar(
        title: const Text('Profil'),
        backgroundColor: const Color(0xFF4A90E2),
        foregroundColor: Colors.white,
      ),

      // Center digunakan untuk menempatkan isi di tengah
      body: Center(
        // Column digunakan untuk menyusun isi secara vertikal
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // CircleAvatar digunakan untuk foto profil
            const CircleAvatar(
              radius: 50,
              backgroundColor: Color(0xFFE4F0FF),

              // Icon digunakan sebagai pengganti foto
              child: Icon(
                Icons.person,
                size: 55,
                color: Color(0xFF4A90E2),
              ),
            ),

            const SizedBox(height: 20),

            // Text menampilkan nama pengguna
            const Text(
              'Angelina',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            // Text menampilkan deskripsi
            const Text(
              'Admin LaundryKu',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}