package com.example.posttest1_2409106014_angelinaaugustinumami;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
