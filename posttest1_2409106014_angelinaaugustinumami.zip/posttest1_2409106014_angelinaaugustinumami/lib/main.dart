import 'package:flutter/material.dart';

void main() {
  runApp(const LaundryKuApp());
}

// MATERIAL APP
// Widget utama untuk membungkus seluruh aplikasi Flutter
class LaundryKuApp extends StatelessWidget {
  const LaundryKuApp({super.key});

  @override
  Widget build(BuildContext context) {
    // MaterialApp digunakan sebagai wrapper utama aplikasi
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      // Mengatur tema warna utama aplikasi
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4A90E2),
        ),
        fontFamily: 'Arial',
        useMaterial3: true,
      ),

      // Menentukan halaman yang pertama kali ditampilkan
      home: const HomePage(),
    );
  }
}

// HOME PAGE
// Halaman utama aplikasi LaundryKu
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // SCAFFOLD
    // Struktur dasar halaman aplikasi
    return Scaffold(
      backgroundColor: const Color(0xFFF5F9FF),

      // APP BAR
      // Bar bagian atas aplikasi
      appBar: AppBar(
        backgroundColor: const Color(0xFF4A90E2),
        elevation: 0,

        // ROW
        // Menyusun icon dan text secara horizontal
        title: Row(
          children: [
            // ICON
            // Menampilkan icon laundry
            const Icon(
              Icons.local_laundry_service,
              color: Colors.white,
              size: 30,
            ),

            // SIZED BOX
            // Memberikan jarak antara icon dan text
            const SizedBox(width: 10),

            // TEXT
            // Menampilkan nama aplikasi
            const Text(
              'LaundryKu',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),

      // BODY
      body: SafeArea(
        // SAFE AREA
        // Memastikan isi aplikasi tidak tertutup area perangkat
        child: SingleChildScrollView(
          // SINGLE CHILD SCROLL VIEW
          // Membuat halaman dapat di-scroll
          child: Padding(
            // PADDING
            // Memberikan jarak isi halaman dari tepi layar
            padding: const EdgeInsets.all(20),

            // COLUMN
            // Menyusun seluruh isi halaman secara vertikal
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // HEADER
                // TEXT
                // Judul sambutan pada halaman utama
                const Text(
                  'Halo, Selamat Datang! 👋',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1F2937),
                  ),
                ),

                // SIZED BOX
                // Memberikan jarak vertikal
                const SizedBox(height: 6),

                // TEXT
                // Deskripsi singkat aplikasi
                const Text(
                  'Kelola kebutuhan laundry kamu dengan mudah.',
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.grey,
                  ),
                ),

                const SizedBox(height: 20),

                // TEXT FIELD
                // Input untuk mencari pesanan laundry
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Cari pesanan atau pelanggan...',

                    // ICON
                    // Icon pencarian pada TextField
                    prefixIcon: const Icon(
                      Icons.search,
                      color: Color(0xFF4A90E2),
                    ),

                    filled: true,
                    fillColor: Colors.white,

                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                // INFORMASI PESANAN
                // TEXT
                // Judul bagian statistik
                const Text(
                  'Ringkasan Laundry',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1F2937),
                  ),
                ),

                const SizedBox(height: 15),
                // ROW
                // Menyusun card statistik secara horizontal
                Row(
                  children: [
                    // EXPANDED
                    // Membuat card pertama mengisi ruang yang tersedia
                    Expanded(
                      child: Container(
                        // CONTAINER
                        // Membuat card statistik pesanan masuk
                        padding: const EdgeInsets.all(16),

                        decoration: BoxDecoration(
                          color: const Color(0xFFE7F1FF),
                          borderRadius: BorderRadius.circular(18),
                        ),

                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            // ICON
                            // Icon untuk pesanan masuk
                            const Icon(
                              Icons.shopping_bag_outlined,
                              color: Color(0xFF4A90E2),
                              size: 30,
                            ),
                            const SizedBox(height: 12),

                            // TEXT
                            // Jumlah pesanan masuk
                            const Text(
                              '12',
                              style: TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),

                            // TEXT
                            // Keterangan statistik
                            const Text(
                              'Pesanan Masuk',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // SIZED BOX
                    // Memberikan jarak antara dua card
                    const SizedBox(width: 12),
                    // EXPANDED
                    // Membuat card kedua mengisi ruang yang tersedia
                    Expanded(
                      child: Container(
                        // CONTAINER
                        // Membuat card statistik laundry selesai
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE9F9F0),
                          borderRadius: BorderRadius.circular(18),
                        ),

                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // ICON
                            // Icon untuk laundry selesai
                            const Icon(
                              Icons.check_circle_outline,
                              color: Color(0xFF28A745),
                              size: 30,
                            ),
                            const SizedBox(height: 12),
                            // TEXT
                            // Jumlah laundry selesai
                            const Text(
                              '8',
                              style: TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            // TEXT
                            // Keterangan statistik
                            const Text(
                              'Sudah Selesai',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 25),

                // LAYANAN LAUNDRY
                // TEXT
                // Judul layanan
                const Text(
                  'Layanan Laundry',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1F2937),
                  ),
                ),
                const SizedBox(height: 15),

                // CONTAINER
                // Card layanan cuci kiloan
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.12),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      // CONTAINER
                      // Kotak background untuk icon
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE7F1FF),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        // ICON
                        // Icon layanan cuci kiloan
                        child: const Icon(
                          Icons.local_laundry_service,
                          color: Color(0xFF4A90E2),
                          size: 28,
                        ),
                      ),
                      // SIZED BOX
                      // Memberikan jarak antara icon dan informasi
                      const SizedBox(width: 15),
                      // EXPANDED
                      // Membuat informasi layanan menggunakan sisa ruang
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            // TEXT
                            // Nama layanan
                            Text(
                              'Cuci Kiloan',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 5),
                            // TEXT
                            // Harga layanan
                            Text(
                              'Mulai dari Rp7.000 / kg',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ICON
                      // Icon panah untuk menunjukkan detail
                      const Icon(
                        Icons.arrow_forward_ios,
                        size: 16,
                        color: Colors.grey,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                // CONTAINER
                // Card layanan cuci satuan
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.12),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),

                  child: Row(
                    children: [
                      // CONTAINER
                      // Background icon layanan satuan
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF3E0),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        // ICON
                        // Icon untuk layanan satuan
                        child: const Icon(
                          Icons.dry_cleaning_outlined,
                          color: Colors.orange,
                          size: 28,
                        ),
                      ),
                      const SizedBox(width: 15),
                      // EXPANDED
                      // Mengisi sisa ruang pada Row
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            // TEXT
                            // Nama layanan
                            Text(
                              'Cuci Satuan',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 5),
                            // TEXT
                            // Informasi harga
                            Text(
                              'Mulai dari Rp5.000 / pcs',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ICON
                      // Icon menuju detail layanan
                      const Icon(
                        Icons.arrow_forward_ios,
                        size: 16,
                        color: Colors.grey,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 25),

                // PESAN SEKARANG
                // CONTAINER
                // Tombol utama untuk membuat pesanan
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    vertical: 18,
                    horizontal: 20,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF4A90E2),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Row(
                    children: [
                      // ICON
                      // Icon tambah pesanan
                      const Icon(
                        Icons.add_circle_outline,
                        color: Colors.white,
                        size: 30,
                      ),
                      const SizedBox(width: 15),
                      // EXPANDED
                      // Mengisi ruang kosong agar teks berada di tengah
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            // TEXT
                            // Judul tombol
                            Text(
                              'Buat Pesanan Baru',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 4),
                            // TEXT
                            // Deskripsi tombol
                            Text(
                              'Catat pesanan laundry pelanggan',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ICON
                      // Icon panah
                      const Icon(
                        Icons.arrow_forward,
                        color: Colors.white,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 25),

                // FOOTER
                // CONTAINER
                // Informasi tambahan aplikasi
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEFF6FF),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Row(
                    children: [
                      // ICON
                      // Icon informasi
                      const Icon(
                        Icons.info_outline,
                        color: Color(0xFF4A90E2),
                      ),
                      const SizedBox(width: 10),
                      // EXPANDED
                      // Agar teks menggunakan ruang yang tersedia
                      const Expanded(
                        child: Text(
                          'LaundryKu membantu mengelola pesanan '
                              'dan layanan laundry dengan lebih praktis.',
                          style: TextStyle(
                            color: Color(0xFF374151),
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // TEXT
                // Copyright aplikasi
                const Center(
                  child: Text(
                    'LaundryKu • Aplikasi Manajemen Laundry',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),

      // BOTTOM NAVIGATION BAR
      // Navigasi bagian bawah aplikasi
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        selectedItemColor: const Color(0xFF4A90E2),
        unselectedItemColor: Colors.grey,
        items: const [
          // ICON + TEXT
          // Menu Home
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Home',
          ),
          // ICON + TEXT
          // Menu Pesanan
          BottomNavigationBarItem(
            icon: Icon(Icons.receipt_long_outlined),
            label: 'Pesanan',
          ),
          // ICON + TEXT
          // Menu Profil
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}