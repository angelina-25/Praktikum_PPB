import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:posttest3_2409106014_angelinaaugustinumami/main.dart';

void main() {
  testWidgets('LaundryKu berhasil ditampilkan', (WidgetTester tester) async {
    // Menjalankan aplikasi LaundryKu
    await tester.pumpWidget(const LaundryKuApp());

    // Memastikan tulisan LaundryKu tampil
    expect(find.text('LaundryKu'), findsOneWidget);
  });
}