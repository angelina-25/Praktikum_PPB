// Model digunakan untuk menyimpan data satu pesanan laundry.
class LaundryOrder {
  String nama;
  String layanan;
  String jumlah;
  String status;

  // Constructor digunakan untuk membuat data pesanan baru.
  LaundryOrder({
    required this.nama,
    required this.layanan,
    required this.jumlah,
    required this.status,
  });
}