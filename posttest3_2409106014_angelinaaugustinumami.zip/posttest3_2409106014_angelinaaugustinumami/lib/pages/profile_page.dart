import 'package:flutter/material.dart';

// StatelessWidget digunakan karena halaman profil tidak memiliki state
// yang perlu diubah pada versi ini.
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur halaman.
    return Scaffold(
      // AppBar digunakan sebagai bagian atas halaman.
      appBar: AppBar(
        title: const Text(
          'Profil',
        ),

        // Warna AppBar.
        backgroundColor: const Color(0xFF4A90E2),

        // Warna tulisan AppBar.
        foregroundColor: Colors.white,
      ),

      // Container digunakan untuk background halaman.
      body: Container(
        width: double.infinity,
        color: const Color(0xFFF5F8FD),

        // Padding memberikan jarak isi halaman.
        child: Padding(
          padding: const EdgeInsets.all(20),

          // Column menyusun informasi secara vertikal.
          child: Column(
            children: [
              // CircleAvatar digunakan untuk foto profil.
              const CircleAvatar(
                radius: 50,

                // Icon profil.
                child: Icon(
                  Icons.person,
                  size: 55,
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 15),

              // Text nama pengguna.
              const Text(
                'Angelina',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 5),

              // Text deskripsi.
              const Text(
                'Pengguna LaundryKu',
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 30),

              // Card informasi profil.
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),

                  // Column menyusun informasi.
                  child: Column(
                    children: [
                      // ListTile informasi nama.
                      const ListTile(
                        leading: Icon(Icons.person),
                        title: Text('Nama'),
                        subtitle: Text('Angelina'),
                      ),

                      // Divider sebagai garis pemisah.
                      const Divider(),

                      // ListTile informasi aplikasi.
                      const ListTile(
                        leading: Icon(Icons.local_laundry_service),
                        title: Text('Aplikasi'),
                        subtitle: Text('LaundryKu'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}