import 'package:flutter/material.dart';

import '../models/laundry_order.dart';

// StatefulWidget digunakan karena status pesanan dapat berubah.
class OrderPage extends StatefulWidget {
  final List<LaundryOrder> orders;
  final Function(int) onStatusChanged;

  const OrderPage({
    super.key,
    required this.orders,
    required this.onStatusChanged,
  });

  @override
  State<OrderPage> createState() => _OrderPageState();
}

// State halaman pesanan.
class _OrderPageState extends State<OrderPage> {
  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur halaman.
    return Scaffold(
      // AppBar digunakan sebagai bagian atas halaman.
      appBar: AppBar(
        title: const Text(
          'Pesanan Laundry',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),

        // Warna AppBar.
        backgroundColor: const Color(0xFF4A90E2),

        // Warna tulisan AppBar.
        foregroundColor: Colors.white,
      ),

      // ListView digunakan untuk menampilkan daftar pesanan.
      body: ListView.builder(
        padding: const EdgeInsets.all(20),

        // Jumlah pesanan.
        itemCount: widget.orders.length,

        // Membuat setiap Card pesanan.
        itemBuilder: (context, index) {
          // Mengambil data pesanan.
          final order = widget.orders[index];

          // Card digunakan sebagai wadah pesanan.
          return Card(
            margin: const EdgeInsets.only(bottom: 15),

            // Padding memberikan ruang dalam Card.
            child: Padding(
              padding: const EdgeInsets.all(16),

              // Column menyusun informasi secara vertikal.
              child: Column(
                children: [
                  // Row menyusun informasi utama.
                  Row(
                    children: [
                      // CircleAvatar sebagai icon pelanggan.
                      const CircleAvatar(
                        radius: 28,
                        child: Icon(Icons.person),
                      ),

                      // SizedBox memberikan jarak.
                      const SizedBox(width: 15),

                      // Expanded memberikan ruang informasi.
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Nama pelanggan.
                            Text(
                              order.nama,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            // Detail layanan.
                            Text(
                              '${order.layanan} • ${order.jumlah}',
                              style: const TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Chip menampilkan status.
                      Chip(
                        label: Text(order.status),
                        backgroundColor: order.status == 'Selesai'
                            ? Colors.green.shade100
                            : Colors.orange.shade100,
                      ),
                    ],
                  ),

                  // SizedBox memberikan jarak.
                  const SizedBox(height: 15),

                  // SizedBox membuat tombol memenuhi lebar.
                  SizedBox(
                    width: double.infinity,

                    // ElevatedButton digunakan untuk mengubah status.
                    child: ElevatedButton.icon(
                      // Ketika tombol ditekan, status diubah.
                      onPressed: () {
                        widget.onStatusChanged(index);

                        // Refresh halaman.
                        setState(() {});
                      },

                      // Icon tombol.
                      icon: const Icon(Icons.sync),

                      // Text tombol.
                      label: Text(
                        order.status == 'Proses'
                            ? 'Tandai Selesai'
                            : 'Ubah ke Proses',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}