import 'package:flutter/material.dart';

// StatelessWidget digunakan karena data layanan bersifat tetap.
class ServicePage extends StatelessWidget {
  const ServicePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur halaman.
    return Scaffold(
      // AppBar digunakan sebagai bagian atas halaman.
      appBar: AppBar(
        title: const Text(
          'Layanan Laundry',
        ),

        // Warna AppBar.
        backgroundColor: const Color(0xFF4A90E2),

        // Warna tulisan AppBar.
        foregroundColor: Colors.white,
      ),

      // ListView digunakan untuk daftar layanan.
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Card layanan Cuci Kiloan.
          _serviceCard(
            icon: Icons.local_laundry_service,
            title: 'Cuci Kiloan',
            description: 'Cuci pakaian berdasarkan berat.',
            price: 'Mulai dari Rp7.000 / kg',
          ),

          // Card layanan Cuci Satuan.
          _serviceCard(
            icon: Icons.checkroom,
            title: 'Cuci Satuan',
            description: 'Cuci pakaian tertentu secara satuan.',
            price: 'Mulai dari Rp10.000 / pcs',
          ),

          // Card layanan Cuci Sepatu.
          _serviceCard(
            icon: Icons.directions_run,
            title: 'Cuci Sepatu',
            description: 'Membersihkan sepatu agar kembali bersih.',
            price: 'Mulai dari Rp20.000 / pasang',
          ),

          // Card layanan Setrika.
          _serviceCard(
            icon: Icons.iron,
            title: 'Setrika',
            description: 'Layanan menyetrika pakaian.',
            price: 'Mulai dari Rp5.000 / kg',
          ),
        ],
      ),
    );
  }

  // Widget helper digunakan untuk membuat Card layanan.
  Widget _serviceCard({
    required IconData icon,
    required String title,
    required String description,
    required String price,
  }) {
    // Card digunakan sebagai wadah informasi layanan.
    return Card(
      margin: const EdgeInsets.only(bottom: 15),

      // Padding memberikan ruang di dalam Card.
      child: Padding(
        padding: const EdgeInsets.all(20),

        // Row menyusun icon dan informasi.
        child: Row(
          children: [
            // CircleAvatar digunakan sebagai icon layanan.
            CircleAvatar(
              radius: 30,
              backgroundColor: const Color(0xFFE2EFFF),

              // Icon layanan.
              child: Icon(
                icon,
                color: const Color(0xFF4A90E2),
                size: 30,
              ),
            ),

            // SizedBox memberikan jarak.
            const SizedBox(width: 15),

            // Expanded memberikan ruang informasi.
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Text nama layanan.
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  // Text deskripsi layanan.
                  Text(
                    description,
                    style: const TextStyle(
                      color: Colors.grey,
                    ),
                  ),

                  // SizedBox memberikan jarak.
                  const SizedBox(height: 5),

                  // Text harga layanan.
                  Text(
                    price,
                    style: const TextStyle(
                      color: Color(0xFF4A90E2),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}