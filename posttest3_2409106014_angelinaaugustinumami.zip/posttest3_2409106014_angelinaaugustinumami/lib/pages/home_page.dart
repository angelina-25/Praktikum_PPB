import 'package:flutter/material.dart';

import '../models/laundry_order.dart';
import 'new_order_page.dart';
import 'service_page.dart';

// StatefulWidget digunakan karena Home memiliki fitur pencarian.
class HomePage extends StatefulWidget {
  final List<LaundryOrder> orders;
  final Function(LaundryOrder) onAddOrder;

  const HomePage({
    super.key,
    required this.orders,
    required this.onAddOrder,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

// State untuk HomePage.
class _HomePageState extends State<HomePage> {
  // Controller digunakan untuk membaca input pencarian.
  final TextEditingController searchController = TextEditingController();

  // Menyimpan teks pencarian.
  String searchText = '';

  @override
  void initState() {
    super.initState();

    // Listener digunakan agar hasil pencarian berubah langsung.
    searchController.addListener(() {
      setState(() {
        searchText = searchController.text.toLowerCase();
      });
    });
  }

  @override
  void dispose() {
    // Controller dibersihkan ketika halaman tidak digunakan.
    searchController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Filter pesanan berdasarkan nama pelanggan.
    final filteredOrders = widget.orders.where((order) {
      return order.nama.toLowerCase().contains(searchText);
    }).toList();

    // Scaffold digunakan sebagai struktur halaman Home.
    return Scaffold(
      // AppBar digunakan sebagai bagian atas halaman.
      appBar: AppBar(
// Row digunakan untuk menampilkan logo dan nama aplikasi.
        title: Row(
          children: [
            // Image.asset digunakan untuk mengambil logo dari folder assets.
            Image.asset(
              'assets/laundry.png',
              width: 35,
              height: 35,
              fit: BoxFit.contain,
            ),

            // SizedBox memberikan jarak antara logo dan tulisan.
            const SizedBox(width: 10),

            // Text digunakan untuk menampilkan nama aplikasi.
            const Text(
              'LaundryKu',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),

        // Background AppBar.
        backgroundColor: const Color(0xFF4A90E2),
      ),

      // Container digunakan sebagai background halaman.
      body: Container(
        color: const Color(0xFFF5F8FD),

        // SingleChildScrollView digunakan agar halaman dapat di-scroll.
        child: SingleChildScrollView(
          // Padding memberikan jarak dari tepi layar.
          padding: const EdgeInsets.all(20),

          // Column menyusun widget secara vertikal.
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Text digunakan untuk ucapan selamat datang.
              const Text(
                'Halo, Selamat Datang! 👋',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 8),

              // Text digunakan untuk deskripsi aplikasi.
              const Text(
                'Kelola kebutuhan laundry kamu dengan mudah.',
                style: TextStyle(
                  fontSize: 17,
                  color: Colors.grey,
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 25),

              // TextField digunakan untuk pencarian.
              TextField(
                controller: searchController,

                // InputDecoration digunakan untuk tampilan TextField.
                decoration: InputDecoration(
                  hintText: 'Cari pesanan atau pelanggan...',

                  // Icon pencarian.
                  prefixIcon: const Icon(Icons.search),

                  // Background TextField.
                  filled: true,

                  // Warna background TextField.
                  fillColor: Colors.white,

                  // Border TextField.
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 30),

              // Text judul ringkasan.
              const Text(
                'Ringkasan Laundry',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 15),

              // Row digunakan untuk dua Card ringkasan.
              Row(
                children: [
                  // Expanded membagi lebar secara merata.
                  Expanded(
                    child: Card(
                      color: const Color(0xFFE2EFFF),

                      // Padding memberikan ruang di dalam Card.
                      child: Padding(
                        padding: const EdgeInsets.all(20),

                        // Column menyusun isi Card.
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Icon menunjukkan jumlah pesanan.
                            const Icon(
                              Icons.shopping_bag_outlined,
                              size: 35,
                              color: Color(0xFF4A90E2),
                            ),

                            // SizedBox memberikan jarak.
                            const SizedBox(height: 10),

                            // Text menampilkan jumlah pesanan.
                            Text(
                              '${widget.orders.length}',
                              style: const TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            // Text keterangan.
                            const Text(
                              'Pesanan Masuk',
                              style: TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // SizedBox memberikan jarak antar Card.
                  const SizedBox(width: 15),

                  // Expanded untuk Card pesanan selesai.
                  Expanded(
                    child: Card(
                      color: const Color(0xFFE2F8EA),

                      // Padding memberikan ruang.
                      child: Padding(
                        padding: const EdgeInsets.all(20),

                        // Column menyusun isi Card.
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Icon menunjukkan status selesai.
                            const Icon(
                              Icons.check_circle_outline,
                              size: 35,
                              color: Colors.green,
                            ),

                            // SizedBox memberikan jarak.
                            const SizedBox(height: 10),

                            // Text menghitung pesanan selesai.
                            Text(
                              '${widget.orders.where((e) => e.status == 'Selesai').length}',
                              style: const TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            // Text keterangan.
                            const Text(
                              'Sudah Selesai',
                              style: TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 30),

              // Judul layanan.
              const Text(
                'Layanan Laundry',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 15),

              // InkWell membuat Card dapat diklik.
              InkWell(
                // Ketika Card diklik, buka ServicePage.
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ServicePage(),
                    ),
                  );
                },

                // Card digunakan untuk layanan laundry.
                child: Card(
                  color: Colors.white,

                  // Padding memberikan ruang.
                  child: Padding(
                    padding: const EdgeInsets.all(20),

                    // Row menyusun icon dan informasi.
                    child: Row(
                      children: [
                        // CircleAvatar sebagai icon layanan.
                        const CircleAvatar(
                          radius: 30,
                          backgroundColor: Color(0xFFE2EFFF),

                          // Icon laundry.
                          child: Icon(
                            Icons.local_laundry_service,
                            color: Color(0xFF4A90E2),
                            size: 30,
                          ),
                        ),

                        // SizedBox memberikan jarak.
                        const SizedBox(width: 15),

                        // Expanded memberikan ruang teks.
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Nama layanan.
                              Text(
                                'Cuci Kiloan',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              // Harga layanan.
                              Text(
                                'Mulai dari Rp7.000 / kg',
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Icon menunjukkan Card dapat diklik.
                        const Icon(
                          Icons.arrow_forward_ios,
                          size: 18,
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 20),

              // SizedBox membuat tombol memenuhi lebar.
              SizedBox(
                width: double.infinity,

                // ElevatedButton digunakan untuk membuat pesanan.
                child: ElevatedButton.icon(
                  // Ketika tombol ditekan, buka NewOrderPage.
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => NewOrderPage(
                          onOrderAdded: widget.onAddOrder,
                        ),
                      ),
                    );

                    // Refresh Home setelah kembali dari halaman tambah pesanan.
                    setState(() {});
                  },

                  // Icon pada tombol.
                  icon: const Icon(Icons.add),

                  // Text pada tombol.
                  label: const Text(
                    'Buat Pesanan Baru',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  // Style tombol.
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF4A90E2),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      vertical: 20,
                    ),
                  ),
                ),
              ),

              // SizedBox memberikan jarak.
              const SizedBox(height: 25),

              // Hanya tampil jika pengguna melakukan pencarian.
              if (searchText.isNotEmpty) ...[
                // Judul hasil pencarian.
                const Text(
                  'Hasil Pencarian',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                // SizedBox memberikan jarak.
                const SizedBox(height: 10),

                // Jika tidak ada hasil.
                if (filteredOrders.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(15),

                    // Text pemberitahuan.
                    child: Text(
                      'Pesanan tidak ditemukan.',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 16,
                      ),
                    ),
                  )
                else

                // ListView digunakan untuk menampilkan hasil pencarian.
                  ListView.builder(
                    shrinkWrap: true,

                    // ListView tidak memiliki scroll sendiri.
                    physics:
                    const NeverScrollableScrollPhysics(),

                    // Jumlah data.
                    itemCount: filteredOrders.length,

                    // Builder setiap item.
                    itemBuilder: (context, index) {
                      // Mengambil data pesanan.
                      final order = filteredOrders[index];

                      // Card digunakan untuk hasil pencarian.
                      return Card(
                        // ListTile digunakan untuk membuat baris data.
                        child: ListTile(
                          // CircleAvatar sebagai icon pelanggan.
                          leading: const CircleAvatar(
                            child: Icon(Icons.person),
                          ),

                          // Nama pelanggan.
                          title: Text(order.nama),

                          // Detail pesanan.
                          subtitle: Text(
                            '${order.layanan} • ${order.jumlah}',
                          ),

                          // Chip menampilkan status.
                          trailing: Chip(
                            label: Text(order.status),
                          ),
                        ),
                      );
                    },
                  ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}