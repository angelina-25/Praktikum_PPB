import 'package:flutter/material.dart';

import '../models/laundry_order.dart';

// StatefulWidget digunakan karena form memiliki data yang berubah.
class NewOrderPage extends StatefulWidget {
  final Function(LaundryOrder) onOrderAdded;

  const NewOrderPage({
    super.key,
    required this.onOrderAdded,
  });

  @override
  State<NewOrderPage> createState() => _NewOrderPageState();
}

// State halaman tambah pesanan.
class _NewOrderPageState extends State<NewOrderPage> {
  // Controller untuk input nama pelanggan.
  final TextEditingController namaController = TextEditingController();

  // Controller untuk input jumlah.
  final TextEditingController jumlahController = TextEditingController();

  // Menyimpan layanan yang dipilih.
  String layanan = 'Cuci Kiloan';

  @override
  void dispose() {
    // Membersihkan controller nama.
    namaController.dispose();

    // Membersihkan controller jumlah.
    jumlahController.dispose();

    super.dispose();
  }

  // Fungsi untuk menyimpan pesanan.
  void simpanPesanan() {
    // Validasi agar nama dan jumlah tidak kosong.
    if (namaController.text.trim().isEmpty ||
        jumlahController.text.trim().isEmpty) {
      // SnackBar memberikan pemberitahuan kepada pengguna.
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Nama dan jumlah pesanan harus diisi.',
          ),
        ),
      );

      return;
    }

    // Membuat object pesanan baru.
    final pesanan = LaundryOrder(
      nama: namaController.text.trim(),
      layanan: layanan,
      jumlah: jumlahController.text.trim(),
      status: 'Proses',
    );

    // Mengirim pesanan ke state utama.
    widget.onOrderAdded(pesanan);

    // Kembali ke halaman sebelumnya.
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    // Scaffold digunakan sebagai struktur halaman.
    return Scaffold(
      // AppBar digunakan sebagai bagian atas halaman.
      appBar: AppBar(
        title: const Text(
          'Buat Pesanan Baru',
        ),

        // Warna AppBar.
        backgroundColor: const Color(0xFF4A90E2),

        // Warna tulisan AppBar.
        foregroundColor: Colors.white,
      ),

      // Padding memberikan jarak isi halaman.
      body: Padding(
        padding: const EdgeInsets.all(20),

        // Column menyusun form secara vertikal.
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Text judul form.
            const Text(
              'Data Pelanggan',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            // SizedBox memberikan jarak.
            const SizedBox(height: 20),

            // TextField untuk nama pelanggan.
            TextField(
              controller: namaController,

              // Decoration untuk TextField.
              decoration: InputDecoration(
                labelText: 'Nama Pelanggan',
                prefixIcon: const Icon(Icons.person),

                // Border TextField.
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ),

            // SizedBox memberikan jarak.
            const SizedBox(height: 15),

            // DropdownButtonFormField digunakan untuk memilih layanan.
            DropdownButtonFormField<String>(
              value: layanan,

              // Decoration dropdown.
              decoration: InputDecoration(
                labelText: 'Jenis Layanan',
                prefixIcon: const Icon(
                  Icons.local_laundry_service,
                ),

                // Border dropdown.
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),

              // Daftar pilihan layanan.
              items: const [
                // Pilihan Cuci Kiloan.
                DropdownMenuItem(
                  value: 'Cuci Kiloan',
                  child: Text('Cuci Kiloan'),
                ),

                // Pilihan Cuci Satuan.
                DropdownMenuItem(
                  value: 'Cuci Satuan',
                  child: Text('Cuci Satuan'),
                ),

                // Pilihan Cuci Sepatu.
                DropdownMenuItem(
                  value: 'Cuci Sepatu',
                  child: Text('Cuci Sepatu'),
                ),

                // Pilihan Setrika.
                DropdownMenuItem(
                  value: 'Setrika',
                  child: Text('Setrika'),
                ),
              ],

              // Mengubah layanan ketika pilihan berubah.
              onChanged: (value) {
                setState(() {
                  layanan = value!;
                });
              },
            ),

            // SizedBox memberikan jarak.
            const SizedBox(height: 15),

            // TextField untuk jumlah pesanan.
            TextField(
              controller: jumlahController,

              // Keyboard angka.
              keyboardType: TextInputType.number,

              // Decoration TextField.
              decoration: InputDecoration(
                labelText: 'Jumlah',
                hintText: 'Contoh: 3 kg / 5 pcs',
                prefixIcon: const Icon(Icons.shopping_bag),

                // Border TextField.
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ),

            // SizedBox memberikan jarak.
            const SizedBox(height: 30),

            // SizedBox membuat tombol memenuhi lebar.
            SizedBox(
              width: double.infinity,

              // ElevatedButton digunakan untuk menyimpan pesanan.
              child: ElevatedButton.icon(
                // Ketika ditekan, jalankan simpanPesanan.
                onPressed: simpanPesanan,

                // Icon tombol.
                icon: const Icon(Icons.save),

                // Text tombol.
                label: const Text(
                  'Simpan Pesanan',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                // Style tombol.
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4A90E2),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    vertical: 18,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}