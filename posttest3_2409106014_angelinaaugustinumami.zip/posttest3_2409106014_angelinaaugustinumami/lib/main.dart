import 'package:flutter/material.dart';

import 'models/laundry_order.dart';
import 'pages/home_page.dart';
import 'pages/order_page.dart';
import 'pages/profile_page.dart';

void main() {
  // runApp digunakan untuk menjalankan aplikasi Flutter.
  runApp(const LaundryKuApp());
}

// StatefulWidget digunakan karena data pesanan dapat berubah.
class LaundryKuApp extends StatefulWidget {
  const LaundryKuApp({super.key});

  @override
  State<LaundryKuApp> createState() => _LaundryKuAppState();
}

// State utama aplikasi LaundryKu.
class _LaundryKuAppState extends State<LaundryKuApp> {
  // Menyimpan index halaman Navigation Bar yang sedang aktif.
  int selectedIndex = 0;

  // List digunakan untuk menyimpan seluruh data pesanan.
  final List<LaundryOrder> orders = [
    LaundryOrder(
      nama: 'Angelina',
      layanan: 'Cuci Kiloan',
      jumlah: '3 kg',
      status: 'Selesai',
    ),
    LaundryOrder(
      nama: 'Putri',
      layanan: 'Cuci Satuan',
      jumlah: '5 pcs',
      status: 'Proses',
    ),
  ];

  // Fungsi untuk menambahkan pesanan baru.
  void tambahPesanan(LaundryOrder pesanan) {
    setState(() {
      orders.add(pesanan);
    });
  }

  // Fungsi untuk mengubah status pesanan.
  void ubahStatus(int index) {
    setState(() {
      if (orders[index].status == 'Proses') {
        orders[index].status = 'Selesai';
      } else {
        orders[index].status = 'Proses';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // MaterialApp digunakan sebagai widget utama aplikasi.
    return MaterialApp(
      // Menghilangkan tulisan DEBUG pada aplikasi.
      debugShowCheckedModeBanner: false,

      // Judul aplikasi.
      title: 'LaundryKu',

      // ThemeData digunakan untuk mengatur tema aplikasi.
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4A90E2),
        ),
        fontFamily: 'Inter',
        useMaterial3: true,
      ),

      // MainPage berada di dalam Navigator yang dibuat oleh MaterialApp.
      home: MainPage(
        orders: orders,
        onAddOrder: tambahPesanan,
        onStatusChanged: ubahStatus,
      ),
    );
  }
}

// StatefulWidget digunakan untuk mengatur NavigationBar.
class MainPage extends StatefulWidget {
  final List<LaundryOrder> orders;
  final Function(LaundryOrder) onAddOrder;
  final Function(int) onStatusChanged;

  const MainPage({
    super.key,
    required this.orders,
    required this.onAddOrder,
    required this.onStatusChanged,
  });

  @override
  State<MainPage> createState() => _MainPageState();
}

// State untuk MainPage.
class _MainPageState extends State<MainPage> {
  // Menentukan halaman yang sedang ditampilkan.
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    // List berisi seluruh halaman aplikasi.
    final pages = [
      // Halaman Home.
      HomePage(
        orders: widget.orders,
        onAddOrder: widget.onAddOrder,
      ),

      // Halaman Pesanan.
      OrderPage(
        orders: widget.orders,
        onStatusChanged: widget.onStatusChanged,
      ),

      // Halaman Profil.
      const ProfilePage(),
    ];

    // Scaffold digunakan sebagai struktur utama halaman.
    return Scaffold(
      // IndexedStack digunakan agar state setiap halaman tetap tersimpan.
      body: IndexedStack(
        index: selectedIndex,
        children: pages,
      ),

      // NavigationBar digunakan untuk berpindah antar halaman.
      bottomNavigationBar: NavigationBar(
        // Menentukan menu yang sedang aktif.
        selectedIndex: selectedIndex,

        // Fungsi ketika menu NavigationBar diklik.
        onDestinationSelected: (index) {
          setState(() {
            selectedIndex = index;
          });
        },

        // Daftar menu NavigationBar.
        destinations: const [
          // Menu Home.
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),

          // Menu Pesanan.
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Pesanan',
          ),

          // Menu Profil.
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}